package app.domain.algorithms;

public class m {
}
