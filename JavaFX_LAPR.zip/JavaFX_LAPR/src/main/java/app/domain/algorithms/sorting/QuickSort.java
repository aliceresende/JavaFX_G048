package app.domain.algorithms.sorting;

//public class QuickSort implements SortingAlgorithm {

//}
