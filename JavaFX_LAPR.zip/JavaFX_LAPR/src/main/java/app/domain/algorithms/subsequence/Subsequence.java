package app.domain.algorithms.subsequence;

public interface Subsequence {
    public int[] getSubsequence(int[] array);
}
