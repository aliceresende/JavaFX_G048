package app.domain.store;

public class NewAdministrationProcessStore {
   /* List<AdministrationProcess> array;
    AdministrationProcess ap;

    public NewAdministrationProcessStore() {
        this.array = new ArrayList<AdministrationProcess>();

    }

    public AdministrationProcess createAdministrationProcess(String code, String vaccine, int VaccineType, int AgeGroup, double DosesToBeAdministered, String vaccineDosage) {
        this.ap = new AdministrationProcess(code, vaccine, VaccineType, AgeGroup, DosesToBeAdministered, vaccineDosage);
        return this.ap;
    }

    private boolean contains(AdministrationProcess ap) {
        if (this.array.contains(ap)) {
            return true;
        } else {
            return false;
        }
    }

    public boolean ValidateAdministrationProcess(AdministrationProcess ap) {
        if (ap == null || contains(ap)) {
            return false;
        }
        return true;
    }

    public boolean saveVaccine() {
        if (ValidateAdministrationProcess(this.ap)) {
            add(ap);
            return true;
        } else {
            return false;
        }
    }

    public boolean add(AdministrationProcess ap) {
        array.add(ap);
        return true;
    }

    public AdministrationProcess getAp() {
        return ap;
    }

    public void setAp(AdministrationProcess ap) {
        this.ap = ap;
    }*/
}



