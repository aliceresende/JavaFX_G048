package app.domain.store;

public class RecordDailyNumberOfVaccinatedPeopleStore {
}
