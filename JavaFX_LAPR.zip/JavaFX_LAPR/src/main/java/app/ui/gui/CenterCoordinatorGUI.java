package app.ui.gui;

/*
public class CenterCoordinatorGUI extends Application implements Runnable {
    public Button button3;
    public Button button2;
    public Button button1;

    public void exitButton(ActionEvent actionEvent) {
        System.exit(0);
    }


    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(CenterCoordinatorGUI.class.getResource("CenterCoordinatorDashboard.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("Center Coordinator Dashboard");
        stage.setScene(scene);
        stage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void run() {
        launch();
    }
}*/
