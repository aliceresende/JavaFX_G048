module com.example.javafx_lapr {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;
    requires Sum;
    requires AuthLib;
    requires commons.lang3;
    requires java.logging;

    opens com.example.javafx_lapr to javafx.fxml;
    exports com.example.javafx_lapr;
}